# -*- coding: utf-8 -*-
"""
Created on Sat Aug 31 14:05:54 2019

@author: saudamini
"""

import turtle 
import math
import random

wn = turtle.Screen()
wn.bgcolor("black")
wn.title("Maze Runner Game")
wn.setup(700, 750)
wn.tracer(0)

treas_list = []    #treasures list
walls = []
wizard_list = []
endlist = []

images = ["keanu2.gif", "treasure.gif", "wiz2.gif", "wall2.gif"]
for image in images :
    turtle.register_shape(image)

class Pen(turtle.Turtle) :
    def __init__(self) :
        turtle.Turtle.__init__(self)
        self.shape("wall2.gif")
        self.penup()
        self.speed(0)
        
class Player(turtle.Turtle) :
    def __init__(self) :
        turtle.Turtle.__init__(self)
        self.shape("keanu2.gif")
        self.penup()
        self.speed(0) 
        self.gold = 0      
    def go_up(self) :
        if (self.xcor(), self.ycor()+24) not in walls :
            self.goto(self.xcor(), self.ycor()+24);
    def go_down(self) :
        if (self.xcor(), self.ycor()-24) not in walls :
            self.goto(self.xcor(), self.ycor()-24);
    def go_right(self) :
        if (self.xcor()+24, self.ycor()) not in walls :
            self.goto(self.xcor()+24, self.ycor());
    def go_left(self) :
        if (self.xcor()-24, self.ycor()) not in walls :
            self.goto(self.xcor()-24, self.ycor());  
    def is_collision(self, other) :
        dist = math.sqrt(((self.xcor() - other.xcor())**2) + (self.ycor() - other.ycor())**2)
        if dist < 5 :
            return True
        else :
            return False    
    def destroy(self) :
        self.goto(2000, 2000)      
        self.hideturtle()      
  
class Endgate(turtle.Turtle) :
    def __init__(self, x, y) :
        turtle.Turtle.__init__(self)
        #self.shape("treasure.gif")
        self.penup()
        self.speed(0)
        self.goto(x,y)     

class Treasure(turtle.Turtle) :
    def __init__(self, x, y) :
        turtle.Turtle.__init__(self)
        self.shape("treasure.gif")
        self.color("Gold")
        self.penup()
        self.speed(0)
        self.gold = 100
        self.goto(x,y)
        
    def destroy(self) :
        self.goto(2000, 2000)      # We cant really destroy it so lets send
        self.hideturtle()          # it to a place where we cant see it.
        
class Wizard(turtle.Turtle) :      
    def __init__(self, x, y) :
        turtle.Turtle.__init__(self)
        self.shape("wiz2.gif")
        self.penup()
        self.speed(0)
        self.gold = 25  
        self.goto(x,y)
        self.direction = random.choice(["up", "down", "left", "right"])
        
    def wiz_move(self) :
        if self.direction == "up" :
            dx = 0
            dy = 24
        elif self.direction == "down" :
            dx = 0
            dy = -24
        elif self.direction == "left" :
            dx = -24
            dy = 0
        elif self.direction == "right" :
            dx = 24
            dy = 0    
        else :
            dx = 0
            dy = 0
        move_to_x = self.xcor() + dx
        move_to_y = self.ycor() + dy
        
        if (move_to_x, move_to_y) not in walls :
            if (move_to_x, move_to_y) not in endlist :
                self.goto(move_to_x,move_to_y)    
        else :
            self.direction = random.choice(["up", "down", "left", "right"])
            
        turtle.ontimer(self.wiz_move, t = random.randint(100, 300)) #the wizard's speed changes every now and then, somewhere between 100-300ms    
        
    def destroy(self) :
        self.goto(2000, 2000)
        self.hideturtle()
        
    def is_collision(self, other) :
        dist = math.sqrt(((self.xcor() - other.xcor())**2) + (self.ycor() - other.ycor())**2)
        if dist < 5 :
            return True
        else :
            return False    
    
levels = ["eeeeeeeeeeeeeeeeeeeeeeeeeee",
          "ex xxxxxxxxxxxxxxexxxxxxxxe",
          "expxxxxxxx xxxxxxt  xx  xxe",
          "ex xxxxxxxt     xxx    xxxe",
          "ex      xxxxxxx  xx xx xxxe",
          "exxxxxx xxxxxxxx xx xx xxxe",
          "exxxxxx     xxxx     x  txe",
          "exxx    xxx xxxxxxx xxxxxxe",
          "exxx xx xxx xxxxx      xxxe",
          "ex   xx  x  xxxxx xxxx xxxe",
          "ex xxxxxx xxxxxxx xx   xxxe",
          "ex xxxxxx xxxxx   xx xxxxxe",
          "ex          xxx xxxx   xxxe",
          "exxx xx xxx     xxxxxx wtxe",
          "exx     xxx xxx   xxx xxxxe",
          "ex  xxx xxx xxxxx xxx  xxxe",
          "ex xxxxxxxx   t   xxxx  xxe",
          "ex    xxxxxxxxxxx w     xxe",
          "ex xxx xxxxxxxxxxxx xxxxxxe",
          "ext     xxxxxxx  xx xxx xxe",
          "exxxxxx          xxt xx xxe",
          "ex  xxx  xxxxx xxxxx xxxxxe",
          "exx  xxx  xxxx xxx     xxxe",
          "exxx xxxx xxxx xx  xxx  xxe",
          "ext        w    t xxxxx  xe",
          "exxxxxxxxxxxxxxxxxxxxxxxexe",
          "eeeeeeeeeeeeeeeeeeeeeeeeeee"]

pen = Pen()
player = Player()

def setup_maze(level) :
    for y in range(len(level)) :
        for x in range(len(level[y])) :
            i = levels[y][x]
            screen_x = -312 + (x*24)
            screen_y = 312 - (y*24)
            
            if i == "x" :
                pen.goto(screen_x, screen_y)
                pen.stamp()
                walls.append((screen_x, screen_y)) #so that all x's can be
                                                   #avoided 
            if i == "p" :
                player.goto(screen_x, screen_y)
            if i == "t" :
                treas_list.append(Treasure(screen_x, screen_y))   #Instances of Treasure in treas_list
            if i == "w":
                wizard_list.append(Wizard(screen_x, screen_y))
            if i == "e" :
                endlist.append(Endgate(screen_x, screen_y))
                
setup_maze(levels)

turtle.listen()                        #Keyboard listener
turtle.onkey(player.go_left, "Left")
turtle.onkey(player.go_right, "Right")
turtle.onkey(player.go_down, "Down")
turtle.onkey(player.go_up, "Up")

wn.tracer(0)  #for disabling the screen for a bit

for wiz in wizard_list :
    turtle.ontimer(wiz.wiz_move, t=250)   #to make wizs move every few seconds.

while True :
    
    for coin in treas_list :
        if player.is_collision(coin) :
            player.gold = player.gold + coin.gold 
            turtle.clear()
            turtle.color("white")
            turtle.penup() 
            turtle.setposition(-130, 325)
            turtle.write("Player Gold : {}".format(player.gold), move=False, align="left", font=("Arial", 28, "normal"))
            #print("Player Gold : {}".format(player.gold))
            coin.destroy()    #Destroy the chest
            treas_list.remove(coin)
            turtle.penup()
    for wiz in wizard_list :
        if player.is_collision(wiz) :
            turtle.clear()
            turtle.color("white")
            turtle.fillcolor("black")
            turtle.penup() 
            turtle.setposition(-270, -40)
            turtle.write("Game Over", move=False, align="left", font=("Arial", 80, "normal")) 
            turtle.setposition(-70, -350)
            turtle.write("Exit Game", move=False, align="left", font=("Arial", 20, "normal"))
            player.destroy()
            
    for end in endlist :
        if player.is_collision(end) :
            turtle.clear()
            turtle.color("white")
            turtle.penup() 
            turtle.setposition(-240, -40)
            turtle.write("You made it out!", move=False, align="left", font=("Arial", 50, "normal"))
            turtle.setposition(-130, 325)
            turtle.write("Player Gold : {}".format(player.gold), move=False, align="left", font=("Arial", 28, "normal"))
            turtle.setposition(-70, -345)
            turtle.write("Exit Game", move=False, align="left", font=("Arial", 20, "normal"))
            player.destroy()
        if wiz.is_collision(end) :
            wiz.direction = random.choice(["up", "down", "left", "right"])
    wn.update()
     